<?php
// Establish database connection
$servername = "sql306.infinityfree.com";
$username = "if0_35155121";
$password = "hetzHVyCsH3sck3";
$dbname = "if0_35155121_k_list";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user input
$username = $_POST['username'];
$userid = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
$email = $_POST['email'];

// Insert user into the database
$sql = "INSERT INTO users (username, password, email, user_id) VALUES ('$username', '$password', '$email', '$userid')";

if ($conn->query($sql) === TRUE) {
    $_SESSION['user'] = $row;
        //echo "Login successful";
        header('Location: ../OkaimonoMake/okaimono.php');
        exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
