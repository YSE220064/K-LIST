<?php
require_once('../WebComponents/functions.php');
loginCheck();
?>

<!-- okaimono.php -->
<!DOCTYPE html>
<html lang="en jp">
<?php include '../WebComponents/head.php'; ?>
<body>
    <?php include '../WebComponents/navigation.php'; ?>  
    <div class="container">
        <div id="shopping-list">
            <h2 id="list-title">何リストを作りたいの？</h2>
            <label for="list-name">リスト名；</label>
            <input type="text" id="list-name" placeholder="リスト名を記入してね！">
            <button onclick="changeListName()">変更</button>
            <ul id="list">
                <!-- Existing items will go here -->
            </ul>
            <div>
                <label for="item">商品名；</label>
                <input type="text" id="item" placeholder="商品名を追加してね！">
                <button onclick="addItem()">追加</button>
            </div>
            
            <p align="center">
            <button onclick="saveList()">リスト　ダウンロード</button>
            <br>
            <!-- <button id="copy-button" onclick="copyLink()">リスト　リンク　コピー</button> -->
            <br>
            <button onclick="savetodb()">データーベース　保存</button>
            <br>
            <br>
            <button onclick="copyLinkAndGenerateQRCode()">QR　コード　作成</button>
            <br>
            </p>

        </div>
        <div id="qrcode"></div>
    </div>
    <?php include '../WebComponents/footer.php'; ?>
    <script src="../WebScripts/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/davidshimjs/qrcodejs/qrcode.min.js"></script>
</body>
</html>
