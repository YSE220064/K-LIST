<!-- head.php -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Language" content="en jp">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../WebCss/WebCss.css">
    <title>K-List</title>
</head>
