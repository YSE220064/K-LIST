<!-- navigation.php -->
<div class="topnav">
    <a href="../index.php">ホーム</a>
    <a href="../OkaimonoMake/okaimono.php">リスト　作る</a>
    <a href="../OkaimonoTables/okaimonolist.php">リスト　一覧</a>
    <a href="../UserSetting/useraccount.php">アカウント　管理</a>
    <a href="../UserRegistration/userregistration.php">アカウント　登録</a>
    <a href="../UserLogin/userlogin.php">アカウント　ログイン</a>
    <a href="../About/about.php">アバウト</a>
    <a href="../UserLogout/userlogout.php">ログアウト</a>
</div>
